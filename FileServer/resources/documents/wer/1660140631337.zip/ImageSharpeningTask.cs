﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using MyTaskScheduler;

// Ctrl K D
namespace MultimediaDataProcessing
{
    /* https://epochabuse.com/color-image-smoothing-and-sharpening/ */
    /* TODO: https://stackoverflow.com/questions/903632/sharpen-on-a-bitmap-using-c-sharp */
    public class ImageSharpeningTask : MyTask
    {
        public ImageSharpeningTask(Priority Priority, long MaxExecutionTime, DateTime Deadline, int NumberOfCores, LinkedList<Resource> Resources) : base(this.ImageSharpen, Priority, MaxExecutionTime, Deadline, NumberOfCores, Resources)
        {

        }
        public Bitmap ImageSharpen(this Bitmap image)
        {
            Console.WriteLine("sharp image");
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            int width = image.Width;
            int height = image.Height;
            BitmapData image_data = image.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            int bytes = image_data.Stride * image_data.Height;
            byte[] buffer = new byte[bytes];
            byte[] result = new byte[bytes];
            Marshal.Copy(image_data.Scan0, buffer, 0, bytes);
            image.UnlockBits(image_data);
            int dim = Kernels.Laplacian.Length;
            int size = dim - 1;

            for (int i = size; i < width - size; i++) // width
            {
                for (int j = size; j < height - size; j++) // height
                {
                    int p = i * dim + j * image_data.Stride;
                    for (int k = 0; k < dim; k++)
                    {
                        double val = 0d;
                        for (int xkernel = -1; xkernel < 2; xkernel++)
                        {
                            for (int ykernel = -1; ykernel < 2; ykernel++)
                            {
                                int kernel_p = k + p + xkernel * 3 + ykernel * image_data.Stride;
                                val += buffer[kernel_p] * Kernels.Laplacian[xkernel + 1, ykernel + 1];
                            }
                        }
                        val = val > 0 ? val : 0;
                        result[p + k] = (byte)((val + buffer[p + k]) > 255 ? 255 : (val + buffer[p + k]));
                    }
                }
            }
            Bitmap res_img = new(width, height);
            BitmapData res_data = res_img.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
            Marshal.Copy(result, 0, res_data.Scan0, bytes);
            res_img.UnlockBits(res_data);
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
            return res_img;
        }


        public Bitmap UnsafeImageSharpen(this Bitmap image)
        {
            Console.WriteLine("unsafe sharp image");
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            int width = image.Width;
            int height = image.Height;
            BitmapData image_data = image.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            Bitmap new_image = (Bitmap)image.Clone();
            BitmapData new_image_data = new_image.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            int bytes = image_data.Stride * image_data.Height;
            Bitmap resultImage;
            BitmapData resultData;
            Console.WriteLine("0");
            unsafe
            {
                byte* buffer = (byte*)(void*)image_data.Scan0;
                Console.WriteLine("00");
                byte* unsafeResult = (byte*)(void*)new_image_data.Scan0;
                //Marshal.Copy(image_data.Scan0, buffer, 0, bytes);
                Console.WriteLine("1");
                //image.UnlockBits(image_data);
                int dim = Kernels.Laplacian.Length;
                int size = dim - 1;

                for (int i = size; i < width - size; i++) // width
                {
                    for (int j = size; j < height - size; j++) // height
                    {
                        int p = i * dim + j * image_data.Stride;
                        for (int k = 0; k < dim; k++)
                        {
                            double val = 0d;
                            for (int xkernel = -1; xkernel < 2; xkernel++)
                            {
                                for (int ykernel = -1; ykernel < 2; ykernel++)
                                {
                                    int kernel_p = k + p + xkernel * 3 + ykernel * image_data.Stride;
                                    val += buffer[kernel_p] * Kernels.Laplacian[xkernel + 1, ykernel + 1];
                                }
                            }
                            val = val > 0 ? val : 0;
                            unsafeResult[p + k] = (byte)((val + buffer[p + k]) > 255 ? 255 : (val + buffer[p + k]));
                        }
                    }
                }

                resultImage = new(width, height);
                resultData = resultImage.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
                byte[] result = new byte[bytes];
                Marshal.Copy((IntPtr)unsafeResult, result, 0, bytes);
                Marshal.Copy(result, 0, resultData.Scan0, bytes);
            }
            //image.UnlockBits(image_data);
            resultImage.UnlockBits(resultData);
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
            return resultImage;
        }
    }
}
